local nope = "recipe-combinator-spoilage-mechanic-recycling"
if data.raw.recipe[nope] then
    data.raw.recipe[nope] = nil
end
