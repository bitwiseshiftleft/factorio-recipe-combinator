local tech = data.raw.technology["advanced-combinators"]
table.insert(tech.effects,{
    type = "unlock-recipe",
    recipe = "recipe-combinator-main"
})
